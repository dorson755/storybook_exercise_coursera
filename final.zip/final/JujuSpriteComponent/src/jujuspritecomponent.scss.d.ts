export const myName: string;
