export const character: string;
export const walkdog: string;
export const flipped: string;
