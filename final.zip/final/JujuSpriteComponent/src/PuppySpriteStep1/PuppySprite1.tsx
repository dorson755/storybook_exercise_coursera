import * as React from 'react';
import * as styles from './PuppySprite1.scss';

export class PuppySpriteStep1 extends React.Component {
  render() {
    return (
      <div className={styles.character}>
      </div>
    );
  }
}

