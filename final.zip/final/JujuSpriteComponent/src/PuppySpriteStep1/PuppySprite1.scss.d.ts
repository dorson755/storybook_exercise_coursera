export const character: string;
export const walkdog: string;
